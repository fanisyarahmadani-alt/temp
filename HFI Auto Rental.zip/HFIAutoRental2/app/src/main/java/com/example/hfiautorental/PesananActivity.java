package com.example.hfiautorental;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PesananActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private PesananAdapter adapter;
    private List<Sewa> pesananList;
    private DatabaseHelper db;
    private View layoutEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesanan);

        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recycler_view_pesanan);
        layoutEmpty = findViewById(R.id.layout_empty);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadPesananData();
    }

    private void loadPesananData() {
        // Ambil data dari database
        pesananList = db.getAllSewa();

        // Jika ada data
        if (pesananList != null && pesananList.size() > 0) {
            recyclerView.setVisibility(View.VISIBLE);
            layoutEmpty.setVisibility(View.GONE);

            adapter = new PesananAdapter(pesananList);
            recyclerView.setAdapter(adapter);
        } else {
            // Jika tidak ada data
            recyclerView.setVisibility(View.GONE);
            layoutEmpty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data setiap kali kembali ke halaman ini
        loadPesananData();
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }
}