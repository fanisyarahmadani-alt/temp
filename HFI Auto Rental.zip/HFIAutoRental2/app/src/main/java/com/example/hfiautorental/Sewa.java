package com.example.hfiautorental;

import java.util.Date;

public class Sewa {
    private int id;
    private String namaPenyewa;
    private String namaMobil;
    private int lamaSewa;
    private int totalHarga;
    private int uangBayar;
    private int uangKembali;
    private String status;
    private String metodePembayaran;
    private String buktiTransferPath; // Baru: path file bukti transfer
    private Date tanggalSewa;

    // Constructors
    public Sewa() {
        this.status = "completed";
        this.metodePembayaran = "COD";
        this.buktiTransferPath = null;
    }

    public Sewa(String namaPenyewa, String namaMobil, int lamaSewa,
                int totalHarga, int uangBayar, int uangKembali) {
        this.namaPenyewa = namaPenyewa;
        this.namaMobil = namaMobil;
        this.lamaSewa = lamaSewa;
        this.totalHarga = totalHarga;
        this.uangBayar = uangBayar;
        this.uangKembali = uangKembali;
        this.status = "completed";
        this.metodePembayaran = "COD";
        this.buktiTransferPath = null;
        this.tanggalSewa = new Date();
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNamaPenyewa() { return namaPenyewa; }
    public void setNamaPenyewa(String namaPenyewa) { this.namaPenyewa = namaPenyewa; }

    public String getNamaMobil() { return namaMobil; }
    public void setNamaMobil(String namaMobil) { this.namaMobil = namaMobil; }

    public int getLamaSewa() { return lamaSewa; }
    public void setLamaSewa(int lamaSewa) { this.lamaSewa = lamaSewa; }

    public int getTotalHarga() { return totalHarga; }
    public void setTotalHarga(int totalHarga) { this.totalHarga = totalHarga; }

    public int getUangBayar() { return uangBayar; }
    public void setUangBayar(int uangBayar) { this.uangBayar = uangBayar; }

    public int getUangKembali() { return uangKembali; }
    public void setUangKembali(int uangKembali) { this.uangKembali = uangKembali; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMetodePembayaran() { return metodePembayaran; }
    public void setMetodePembayaran(String metodePembayaran) { this.metodePembayaran = metodePembayaran; }

    public String getBuktiTransferPath() { return buktiTransferPath; } // Baru
    public void setBuktiTransferPath(String buktiTransferPath) { this.buktiTransferPath = buktiTransferPath; } // Baru

    public Date getTanggalSewa() { return tanggalSewa; }
    public void setTanggalSewa(Date tanggalSewa) { this.tanggalSewa = tanggalSewa; }
}