package com.example.hfiautorental;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "rental_mobil.db";
    private static final int DATABASE_VERSION = 6; // VERSI 6 KARENA ADA PERUBAHAN STRUKTUR

    private static final String TAG = "DatabaseHelper";

    // ========== TABLE USERS ==========
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    // ========== TABLE MOBIL ==========
    private static final String TABLE_MOBIL = "mobil";
    private static final String COLUMN_MOBIL_ID = "mobil_id";
    private static final String COLUMN_MOBIL_NAMA = "nama_mobil";
    private static final String COLUMN_TAHUN = "tahun";
    private static final String COLUMN_KAPASITAS = "kapasitas";
    private static final String COLUMN_HARGA = "harga_per_hari";
    private static final String COLUMN_GAMBAR = "gambar";
    private static final String COLUMN_STATUS_MOBIL = "status_mobil";

    // ========== TABLE SEWA ==========
    private static final String TABLE_SEWA = "sewa";
    private static final String COLUMN_SEWA_ID = "sewa_id";
    private static final String COLUMN_NAMA_PENYEWA = "nama_penyewa";
    private static final String COLUMN_SEWA_NAMA_MOBIL = "nama_mobil_sewa";
    private static final String COLUMN_LAMA_SEWA = "lama_sewa";
    private static final String COLUMN_TOTAL_HARGA = "total_harga";
    private static final String COLUMN_UANG_BAYAR = "uang_bayar";
    private static final String COLUMN_UANG_KEMBALI = "uang_kembali";
    private static final String COLUMN_STATUS_SEWA = "status_sewa";
    private static final String COLUMN_METODE_PEMBAYARAN = "metode_pembayaran";
    private static final String COLUMN_BUKTI_TRANSFER = "bukti_transfer"; // TAMBAHAN BARU
    private static final String COLUMN_TANGGAL = "tanggal_sewa";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT NOT NULL UNIQUE,"
                + COLUMN_EMAIL + " TEXT NOT NULL UNIQUE,"
                + COLUMN_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(CREATE_USERS_TABLE);

        // Create mobil table
        String CREATE_MOBIL_TABLE = "CREATE TABLE " + TABLE_MOBIL + "("
                + COLUMN_MOBIL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_MOBIL_NAMA + " TEXT NOT NULL,"
                + COLUMN_TAHUN + " INTEGER DEFAULT 2020,"
                + COLUMN_KAPASITAS + " INTEGER DEFAULT 5,"
                + COLUMN_HARGA + " INTEGER NOT NULL,"
                + COLUMN_GAMBAR + " TEXT,"
                + COLUMN_STATUS_MOBIL + " TEXT DEFAULT 'Tersedia')";
        db.execSQL(CREATE_MOBIL_TABLE);

        // Create sewa table DENGAN METODE PEMBAYARAN DAN BUKTI TRANSFER
        String CREATE_SEWA_TABLE = "CREATE TABLE " + TABLE_SEWA + "("
                + COLUMN_SEWA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NAMA_PENYEWA + " TEXT NOT NULL,"
                + COLUMN_SEWA_NAMA_MOBIL + " TEXT NOT NULL,"
                + COLUMN_LAMA_SEWA + " INTEGER NOT NULL,"
                + COLUMN_TOTAL_HARGA + " INTEGER NOT NULL,"
                + COLUMN_UANG_BAYAR + " INTEGER NOT NULL,"
                + COLUMN_UANG_KEMBALI + " INTEGER NOT NULL,"
                + COLUMN_STATUS_SEWA + " TEXT DEFAULT 'completed',"
                + COLUMN_METODE_PEMBAYARAN + " TEXT DEFAULT 'COD',"
                + COLUMN_BUKTI_TRANSFER + " TEXT," // UNTUK PATH/URL BUKTI TRANSFER
                + COLUMN_TANGGAL + " DATETIME DEFAULT CURRENT_TIMESTAMP)";
        db.execSQL(CREATE_SEWA_TABLE);

        // Insert sample data
        insertSampleData(db);
    }

    private void insertSampleData(SQLiteDatabase db) {
        // Insert default admin user
        ContentValues userValues = new ContentValues();
        userValues.put(COLUMN_USERNAME, "admin");
        userValues.put(COLUMN_EMAIL, "admin@rental.com");
        userValues.put(COLUMN_PASSWORD, "admin123");
        db.insert(TABLE_USERS, null, userValues);

        // Insert sample mobil data
        ContentValues mobilValues = new ContentValues();

        mobilValues.put(COLUMN_MOBIL_NAMA, "Toyota Avanza");
        mobilValues.put(COLUMN_TAHUN, 2020);
        mobilValues.put(COLUMN_KAPASITAS, 7);
        mobilValues.put(COLUMN_HARGA, 300000);
        mobilValues.put(COLUMN_GAMBAR, "ic_avanza");
        mobilValues.put(COLUMN_STATUS_MOBIL, "Tersedia");
        db.insert(TABLE_MOBIL, null, mobilValues);

        mobilValues.clear();
        mobilValues.put(COLUMN_MOBIL_NAMA, "Daihatsu Xenia");
        mobilValues.put(COLUMN_TAHUN, 2020);
        mobilValues.put(COLUMN_KAPASITAS, 7);
        mobilValues.put(COLUMN_HARGA, 350000);
        mobilValues.put(COLUMN_GAMBAR, "ic_xenia");
        mobilValues.put(COLUMN_STATUS_MOBIL, "Tersedia");
        db.insert(TABLE_MOBIL, null, mobilValues);

        mobilValues.clear();
        mobilValues.put(COLUMN_MOBIL_NAMA, "Mitsubishi Pajero");
        mobilValues.put(COLUMN_TAHUN, 2020);
        mobilValues.put(COLUMN_KAPASITAS, 7);
        mobilValues.put(COLUMN_HARGA, 600000);
        mobilValues.put(COLUMN_GAMBAR, "ic_pajero");
        mobilValues.put(COLUMN_STATUS_MOBIL, "Tersedia");
        db.insert(TABLE_MOBIL, null, mobilValues);

        mobilValues.clear();
        mobilValues.put(COLUMN_MOBIL_NAMA, "Toyota Fortuner");
        mobilValues.put(COLUMN_TAHUN, 2021);
        mobilValues.put(COLUMN_KAPASITAS, 7);
        mobilValues.put(COLUMN_HARGA, 700000);
        mobilValues.put(COLUMN_GAMBAR, "ic_fortuner");
        mobilValues.put(COLUMN_STATUS_MOBIL, "Tersedia");
        db.insert(TABLE_MOBIL, null, mobilValues);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Upgrade dari versi lama ke versi 6
        if (oldVersion < 5) {
            // Jika dari versi < 5, tambahkan kolom metode_pembayaran
            db.execSQL("ALTER TABLE " + TABLE_SEWA + " ADD COLUMN " + COLUMN_METODE_PEMBAYARAN + " TEXT DEFAULT 'COD'");
        }
        if (oldVersion < 6) {
            // Jika dari versi < 6, tambahkan kolom bukti_transfer
            db.execSQL("ALTER TABLE " + TABLE_SEWA + " ADD COLUMN " + COLUMN_BUKTI_TRANSFER + " TEXT");
        }

        // Untuk perubahan besar, bisa drop dan recreate
        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOBIL);
        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_SEWA);
        // onCreate(db);
    }

    // ========== USER OPERATIONS ==========
    public long addUser(String username, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);

        long id = db.insert(TABLE_USERS, null, values);
        db.close();
        return id;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_EMAIL + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {email, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }

    public String getUsernameByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String username = null;

        String query = "SELECT " + COLUMN_USERNAME + " FROM " + TABLE_USERS +
                " WHERE " + COLUMN_EMAIL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email});

        if (cursor.moveToFirst()) {
            username = cursor.getString(0);
        }

        cursor.close();
        db.close();
        return username;
    }

    public boolean isEmailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_EMAIL + " = ?",
                new String[]{email},
                null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // ========== MOBIL OPERATIONS ==========
    public List<Mobil> getAllMobil() {
        List<Mobil> mobilList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_MOBIL,
                    null, null, null, null, null, COLUMN_MOBIL_NAMA + " ASC");

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Mobil mobil = new Mobil();
                    mobil.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MOBIL_ID)));
                    mobil.setNama(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MOBIL_NAMA)));
                    mobil.setTahun(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TAHUN)));
                    mobil.setKapasitas(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_KAPASITAS)));
                    mobil.setHargaPerHari(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_HARGA)));

                    String gambar = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GAMBAR));
                    mobil.setGambar(gambar != null ? gambar : "ic_car");

                    mobilList.add(mobil);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting mobil: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return mobilList;
    }

    public Mobil getMobilByName(String namaMobil) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_MOBIL,
                    null,
                    COLUMN_MOBIL_NAMA + " = ?",
                    new String[]{namaMobil},
                    null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                Mobil mobil = new Mobil();
                mobil.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MOBIL_ID)));
                mobil.setNama(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MOBIL_NAMA)));
                mobil.setTahun(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TAHUN)));
                mobil.setKapasitas(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_KAPASITAS)));
                mobil.setHargaPerHari(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_HARGA)));

                String gambar = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GAMBAR));
                mobil.setGambar(gambar != null ? gambar : "ic_car");

                return mobil;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting mobil by name: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return null;
    }

    // ========== SEWA OPERATIONS ==========
    public long addSewa(Sewa sewa) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_NAMA_PENYEWA, sewa.getNamaPenyewa());
        values.put(COLUMN_SEWA_NAMA_MOBIL, sewa.getNamaMobil());
        values.put(COLUMN_LAMA_SEWA, sewa.getLamaSewa());
        values.put(COLUMN_TOTAL_HARGA, sewa.getTotalHarga());
        values.put(COLUMN_UANG_BAYAR, sewa.getUangBayar());
        values.put(COLUMN_UANG_KEMBALI, sewa.getUangKembali());
        values.put(COLUMN_STATUS_SEWA, sewa.getStatus() != null ? sewa.getStatus() : "completed");

        // Tambahkan metode pembayaran
        values.put(COLUMN_METODE_PEMBAYARAN, sewa.getMetodePembayaran() != null ? sewa.getMetodePembayaran() : "COD");

        // Tambahkan bukti transfer jika ada
        if (sewa.getBuktiTransferPath() != null) {
            values.put(COLUMN_BUKTI_TRANSFER, sewa.getBuktiTransferPath());
        }

        long id = db.insert(TABLE_SEWA, null, values);
        db.close();
        return id;
    }

    public List<Sewa> getAllSewa() {
        List<Sewa> sewaList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_SEWA,
                    null, null, null, null, null, COLUMN_TANGGAL + " DESC");

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Sewa sewa = new Sewa();
                    sewa.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_SEWA_ID)));
                    sewa.setNamaPenyewa(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAMA_PENYEWA)));
                    sewa.setNamaMobil(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SEWA_NAMA_MOBIL)));
                    sewa.setLamaSewa(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_LAMA_SEWA)));
                    sewa.setTotalHarga(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_HARGA)));
                    sewa.setUangBayar(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_UANG_BAYAR)));
                    sewa.setUangKembali(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_UANG_KEMBALI)));
                    sewa.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS_SEWA)));

                    // Ambil metode pembayaran
                    int metodeIndex = cursor.getColumnIndex(COLUMN_METODE_PEMBAYARAN);
                    if (metodeIndex != -1) {
                        sewa.setMetodePembayaran(cursor.getString(metodeIndex));
                    } else {
                        sewa.setMetodePembayaran("COD");
                    }

                    // Ambil bukti transfer
                    int buktiIndex = cursor.getColumnIndex(COLUMN_BUKTI_TRANSFER);
                    if (buktiIndex != -1) {
                        sewa.setBuktiTransferPath(cursor.getString(buktiIndex));
                    }

                    // Tanggal
                    String dateStr = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TANGGAL));
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                        Date date = sdf.parse(dateStr);
                        sewa.setTanggalSewa(date);
                    } catch (Exception e) {
                        sewa.setTanggalSewa(new Date());
                    }

                    sewaList.add(sewa);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting sewa: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return sewaList;
    }

    public int getTotalSewaCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_SEWA, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return count;
    }

    public int getMobilCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_MOBIL, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return count;
    }
}