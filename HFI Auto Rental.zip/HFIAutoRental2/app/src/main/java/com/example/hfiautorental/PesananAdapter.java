package com.example.hfiautorental;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class PesananAdapter extends RecyclerView.Adapter<PesananAdapter.ViewHolder> {
    private List<Sewa> pesananList;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
    private DecimalFormat currencyFormat = new DecimalFormat("###,###");

    public PesananAdapter(List<Sewa> pesananList) {
        this.pesananList = pesananList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pesanan, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Sewa sewa = pesananList.get(position);

        // Format tanggal
        if (sewa.getTanggalSewa() != null) {
            holder.tvTanggal.setText(dateFormat.format(sewa.getTanggalSewa()));
        } else {
            holder.tvTanggal.setText("-");
        }

        // Set data
        holder.tvNamaPenyewa.setText("Nama: " + sewa.getNamaPenyewa());
        holder.tvNamaMobil.setText("Mobil: " + sewa.getNamaMobil());
        holder.tvLamaSewa.setText("Durasi: " + sewa.getLamaSewa() + " hari");

        // Format currency
        holder.tvTotalHarga.setText("Total: Rp " + currencyFormat.format(sewa.getTotalHarga()));
        holder.tvUangBayar.setText("Bayar: Rp " + currencyFormat.format(sewa.getUangBayar()));
        holder.tvUangKembali.setText("Kembali: Rp " + currencyFormat.format(sewa.getUangKembali()));

        // Set status dengan warna berbeda
        String status = sewa.getStatus();
        holder.tvStatus.setText(status);

        // Beri warna berdasarkan status
        int color;
        switch (status.toLowerCase()) {
            case "completed":
                color = holder.itemView.getContext().getResources().getColor(R.color.success_green);
                holder.tvStatus.setText("✅ Selesai");
                break;
            case "pending":
                color = holder.itemView.getContext().getResources().getColor(R.color.warning_orange);
                holder.tvStatus.setText("⏳ Pending");
                break;
            case "cancelled":
                color = holder.itemView.getContext().getResources().getColor(R.color.error_red);
                holder.tvStatus.setText("❌ Dibatalkan");
                break;
            default:
                color = holder.itemView.getContext().getResources().getColor(R.color.success_green);
                holder.tvStatus.setText("✔️ " + status);
        }
        holder.tvStatus.setTextColor(color);
    }

    @Override
    public int getItemCount() {
        return pesananList.size();
    }

    public void updateList(List<Sewa> newList) {
        pesananList = newList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTanggal, tvNamaPenyewa, tvNamaMobil, tvLamaSewa;
        TextView tvTotalHarga, tvUangBayar, tvUangKembali, tvStatus;

        public ViewHolder(View itemView) {
            super(itemView);
            tvTanggal = itemView.findViewById(R.id.tv_tanggal);
            tvNamaPenyewa = itemView.findViewById(R.id.tv_nama_penyewa);
            tvNamaMobil = itemView.findViewById(R.id.tv_nama_mobil);
            tvLamaSewa = itemView.findViewById(R.id.tv_lama_sewa);
            tvTotalHarga = itemView.findViewById(R.id.tv_total_harga);
            tvUangBayar = itemView.findViewById(R.id.tv_uang_bayar);
            tvUangKembali = itemView.findViewById(R.id.tv_uang_kembali);
            tvStatus = itemView.findViewById(R.id.tv_status);
        }
    }
}