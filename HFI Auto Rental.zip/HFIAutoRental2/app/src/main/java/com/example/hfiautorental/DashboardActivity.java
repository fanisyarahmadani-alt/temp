package com.example.hfiautorental;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvWelcome, tvStats;
    private CardView btnInfoMobil, btnSewaMobil, btnContact, btnPesanan, btnLogout;
    private SessionManager sessionManager;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        sessionManager = new SessionManager(this);
        dbHelper = new DatabaseHelper(this);

        if (!sessionManager.isLoggedIn()) {
            redirectToLogin();
            return;
        }

        tvWelcome = findViewById(R.id.tv_welcome);
        tvStats = findViewById(R.id.tv_stats);

        btnInfoMobil = findViewById(R.id.btn_info_mobil);
        btnSewaMobil = findViewById(R.id.btn_sewa_mobil);
        btnContact = findViewById(R.id.btn_contact);
        btnPesanan = findViewById(R.id.btn_pesanan);
        btnLogout = findViewById(R.id.btn_logout);

        String username = sessionManager.getUsername();
        if (username != null) {
            tvWelcome.setText("Welcome, " + username + "!");
        }

        btnInfoMobil.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, MobilInfoActivity.class));
        });

        btnSewaMobil.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, SewaActivity.class));
        });

        btnContact.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, ContactActivity.class));
        });

        btnPesanan.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, PesananActivity.class));
        });

        btnLogout.setOnClickListener(v -> {
            sessionManager.logout();
            Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
            redirectToLogin();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardStats();

        if (!sessionManager.isLoggedIn()) {
            redirectToLogin();
        }
    }

    private void loadDashboardStats() {
        try {
            int totalMobil = dbHelper.getMobilCount();
            int totalSewa = dbHelper.getTotalSewaCount();

            String statsText = "📊 Statistik:\n" +
                    "• Mobil Tersedia: " + totalMobil + "\n" +
                    "• Total Sewa: " + totalSewa;

            if (tvStats != null) {
                tvStats.setText(statsText);
            }
        } catch (Exception e) {
            if (tvStats != null) {
                tvStats.setText("Statistik tidak tersedia");
            }
        }
    }

    private void redirectToLogin() {
        Intent intent = new Intent(DashboardActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (dbHelper != null) {
            dbHelper.close();
        }
        super.onDestroy();
    }
}