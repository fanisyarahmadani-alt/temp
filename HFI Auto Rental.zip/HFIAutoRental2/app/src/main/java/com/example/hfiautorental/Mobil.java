package com.example.hfiautorental;

public class Mobil {
    private int id;
    private String nama;
    private int tahun;
    private int kapasitas;
    private int hargaPerHari;
    private String gambar;

    // Constructors
    public Mobil() {}

    public Mobil(int id, String nama, int tahun, int kapasitas, int hargaPerHari, String gambar) {
        this.id = id;
        this.nama = nama;
        this.tahun = tahun;
        this.kapasitas = kapasitas;
        this.hargaPerHari = hargaPerHari;
        this.gambar = gambar;
    }

    public Mobil(String nama, int tahun, int kapasitas, int hargaPerHari, String gambar) {
        this.nama = nama;
        this.tahun = tahun;
        this.kapasitas = kapasitas;
        this.hargaPerHari = hargaPerHari;
        this.gambar = gambar;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public int getTahun() { return tahun; }
    public void setTahun(int tahun) { this.tahun = tahun; }

    public int getKapasitas() { return kapasitas; }
    public void setKapasitas(int kapasitas) { this.kapasitas = kapasitas; }

    public int getHargaPerHari() { return hargaPerHari; }
    public void setHargaPerHari(int hargaPerHari) { this.hargaPerHari = hargaPerHari; }

    public String getGambar() { return gambar; }
    public void setGambar(String gambar) { this.gambar = gambar; }

    // Method untuk mendapatkan resource ID gambar
    public int getGambarResourceId() {
        if (gambar != null) {
            switch (gambar) {
                case "ic_avanza":
                    return R.drawable.ic_avanza;
                case "ic_xenia":
                    return R.drawable.ic_xenia;
                case "ic_pajero":
                    return R.drawable.ic_pajero;
                case "ic_fortuner":
                    return R.drawable.ic_fortuner;
                default:
                    return R.drawable.ic_car;
            }
        }
        return R.drawable.ic_car;
    }
}