package com.example.hfiautorental;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

public class PembayaranActivity extends AppCompatActivity {
    private TextView tvStatus, tvNama, tvMobil, tvLamaSewa, tvTotal, tvUangBayar, tvUangKembali, tvMetodeBayar;
    private Button btnBackHome;
    private DecimalFormat currencyFormat = new DecimalFormat("###,###");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran);

        // Inisialisasi view
        tvStatus = findViewById(R.id.tv_status);
        tvNama = findViewById(R.id.tv_nama);
        tvMobil = findViewById(R.id.tv_mobil);
        tvLamaSewa = findViewById(R.id.tv_lama_sewa);
        tvTotal = findViewById(R.id.tv_total);
        tvUangBayar = findViewById(R.id.tv_uang_bayar);
        tvUangKembali = findViewById(R.id.tv_uang_kembali);
        tvMetodeBayar = findViewById(R.id.tv_metode_bayar); // Baru
        btnBackHome = findViewById(R.id.btn_back_home);

        // Ambil data dari intent
        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String mobil = intent.getStringExtra("mobil");
        int lamaSewa = intent.getIntExtra("lama_sewa", 0);
        int total = intent.getIntExtra("total", 0);
        int uangBayar = intent.getIntExtra("uang_bayar", 0);
        int uangKembali = intent.getIntExtra("uang_kembali", 0);
        String metodeBayar = intent.getStringExtra("metode_bayar"); // Ambil metode pembayaran

        // Set data ke view
        if (tvNama != null) tvNama.setText(nama != null ? nama : "");
        if (tvMobil != null) tvMobil.setText(mobil != null ? mobil : "");
        if (tvLamaSewa != null) tvLamaSewa.setText(lamaSewa + " hari");
        if (tvTotal != null) tvTotal.setText("Rp " + currencyFormat.format(total));
        if (tvUangBayar != null) tvUangBayar.setText("Rp " + currencyFormat.format(uangBayar));
        if (tvUangKembali != null) tvUangKembali.setText("Rp " + currencyFormat.format(uangKembali));
        if (tvStatus != null) tvStatus.setText("✅ PEMBAYARAN BERHASIL");

        // Set metode pembayaran
        if (tvMetodeBayar != null) {
            if (metodeBayar != null && !metodeBayar.isEmpty()) {
                tvMetodeBayar.setText(metodeBayar);
            } else {
                tvMetodeBayar.setText("COD");
            }
        }

        // Setup back button
        if (btnBackHome != null) {
            btnBackHome.setOnClickListener(v -> goBackToDashboard());
        }

        // Setup back navigation
        setupBackNavigation();
    }

    private void setupBackNavigation() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                goBackToDashboard();
            }
        });
    }

    private void goBackToDashboard() {
        Intent homeIntent = new Intent(PembayaranActivity.this, DashboardActivity.class);
        homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(homeIntent);
        finish();
    }
}