package com.example.hfiautorental;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class SewaActivity extends AppCompatActivity {
    private EditText etNamaPenyewa, etLamaSewa, etUangBayar;
    private Spinner spinnerMobil, spinnerMetodePembayaran;
    private TextView tvHargaMobil, tvHargaTotal, tvUangKembali, tvNamaFile;
    private Button btnHitung, btnOk, btnSewa, btnKeluar, btnUnggahBukti;
    private LinearLayout layoutBuktiTransfer;
    private DatabaseHelper db;
    private List<Mobil> mobilList;
    private Mobil selectedMobil;
    private int totalHarga = 0;
    private String selectedMetodePembayaran;
    private String buktiTransferPath = null; // path file bukti transfer

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sewa);

        db = new DatabaseHelper(this);

        etNamaPenyewa = findViewById(R.id.et_nama_penyewa);
        etLamaSewa = findViewById(R.id.et_lama_sewa);
        etUangBayar = findViewById(R.id.et_uang_bayar);
        spinnerMobil = findViewById(R.id.spinner_mobil);
        spinnerMetodePembayaran = findViewById(R.id.spinner_metode_pembayaran);
        tvHargaMobil = findViewById(R.id.tv_harga_mobil);
        tvHargaTotal = findViewById(R.id.tv_harga_total);
        tvUangKembali = findViewById(R.id.tv_uang_kembali);
        tvNamaFile = findViewById(R.id.tv_nama_file);
        btnHitung = findViewById(R.id.btn_hitung);
        btnOk = findViewById(R.id.btn_ok);
        btnSewa = findViewById(R.id.btn_sewa);
        btnKeluar = findViewById(R.id.btn_keluar);
        btnUnggahBukti = findViewById(R.id.btn_unggah_bukti);
        layoutBuktiTransfer = findViewById(R.id.layout_bukti_transfer);

        // Load data mobil ke Spinner
        loadMobilData();

        // Setup metode pembayaran
        setupMetodePembayaran();

        // Listener ketika pilih mobil di Spinner
        spinnerMobil.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                if (mobilList != null && position < mobilList.size()) {
                    selectedMobil = mobilList.get(position);
                    tvHargaMobil.setText("Harga: Rp " + formatCurrency(selectedMobil.getHargaPerHari()) + "/hari");
                    resetPerhitungan();
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });

        // Listener untuk metode pembayaran
        spinnerMetodePembayaran.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedMetodePembayaran = parent.getItemAtPosition(position).toString();

                // Tampilkan/sembunyikan bukti transfer
                if (selectedMetodePembayaran.equals("COD")) {
                    layoutBuktiTransfer.setVisibility(android.view.View.GONE);
                } else {
                    layoutBuktiTransfer.setVisibility(android.view.View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
                selectedMetodePembayaran = "COD";
                layoutBuktiTransfer.setVisibility(android.view.View.GONE);
            }
        });

        // Listener untuk tombol unggah bukti
        btnUnggahBukti.setOnClickListener(v -> {
            // TODO: Implementasi pemilihan file/gambar
            // Contoh sederhana:
            Toast.makeText(this, "Fitur upload bukti transfer akan segera tersedia", Toast.LENGTH_SHORT).show();
            // Untuk implementasi sebenarnya, gunakan Intent.ACTION_GET_CONTENT atau Intent.ACTION_PICK
        });

        btnHitung.setOnClickListener(v -> hitungTotal());
        btnOk.setOnClickListener(v -> hitungTotal());
        btnSewa.setOnClickListener(v -> prosesSewa());
        btnKeluar.setOnClickListener(v -> finish());
    }

    private void setupMetodePembayaran() {
        // Buat list metode pembayaran
        List<String> metodeList = new ArrayList<>();
        metodeList.add("COD");
        metodeList.add("Transfer Bank");
        metodeList.add("E-Wallet (Dana/OVO/GoPay)");
        metodeList.add("Kartu Kredit");
        metodeList.add("Kartu Debit");

        // Set adapter untuk spinner metode pembayaran
        ArrayAdapter<String> adapterMetode = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, metodeList);
        adapterMetode.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMetodePembayaran.setAdapter(adapterMetode);

        // Set default value
        selectedMetodePembayaran = "COD";
        layoutBuktiTransfer.setVisibility(android.view.View.GONE);
    }

    private void loadMobilData() {
        mobilList = db.getAllMobil();

        if (mobilList == null || mobilList.isEmpty()) {
            Toast.makeText(this, "Tidak ada mobil tersedia", Toast.LENGTH_SHORT).show();
            return;
        }

        // Buat array nama mobil untuk Spinner
        String[] mobilNames = new String[mobilList.size()];
        for (int i = 0; i < mobilList.size(); i++) {
            mobilNames[i] = mobilList.get(i).getNama();
        }

        // Set adapter untuk Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, mobilNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMobil.setAdapter(adapter);

        // Set mobil pertama sebagai default
        if (!mobilList.isEmpty()) {
            selectedMobil = mobilList.get(0);
            tvHargaMobil.setText("Harga: Rp " + formatCurrency(selectedMobil.getHargaPerHari()) + "/hari");
        }
    }

    private void hitungTotal() {
        String lamaSewaStr = etLamaSewa.getText().toString().trim();

        if (lamaSewaStr.isEmpty()) {
            etLamaSewa.setError("Masukkan lama sewa");
            etLamaSewa.requestFocus();
            return;
        }

        if (selectedMobil == null) {
            Toast.makeText(this, "Pilih mobil terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int lamaSewa = Integer.parseInt(lamaSewaStr);

            if (lamaSewa <= 0) {
                etLamaSewa.setError("Lama sewa harus lebih dari 0");
                etLamaSewa.requestFocus();
                return;
            }

            totalHarga = selectedMobil.getHargaPerHari() * lamaSewa;

            // Update UI
            tvHargaTotal.setText("Rp " + formatCurrency(totalHarga));

            // Hitung kembalian jika uang bayar sudah diisi
            String uangBayarStr = etUangBayar.getText().toString().trim();
            if (!uangBayarStr.isEmpty()) {
                hitungKembalian(uangBayarStr);
            }

            Toast.makeText(this, "Total harga: Rp " + formatCurrency(totalHarga), Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            etLamaSewa.setError("Masukkan angka yang valid");
            etLamaSewa.requestFocus();
        }
    }

    private void hitungKembalian(String uangBayarStr) {
        try {
            int uangBayar = Integer.parseInt(uangBayarStr);
            int uangKembali = uangBayar - totalHarga;

            if (uangKembali >= 0) {
                tvUangKembali.setText("Rp " + formatCurrency(uangKembali));
                tvUangKembali.setTextColor(getResources().getColor(R.color.success_green));
            } else {
                tvUangKembali.setText("Uang kurang: Rp " + formatCurrency(Math.abs(uangKembali)));
                tvUangKembali.setTextColor(getResources().getColor(R.color.error_red));
            }
        } catch (NumberFormatException e) {
            tvUangKembali.setText("Masukkan angka yang valid");
            tvUangKembali.setTextColor(getResources().getColor(R.color.error_red));
        }
    }

    private void resetPerhitungan() {
        totalHarga = 0;
        tvHargaTotal.setText("Rp 0");
        tvUangKembali.setText("Rp 0");
        tvUangKembali.setTextColor(getResources().getColor(R.color.success_green));
    }

    private void prosesSewa() {
        String namaPenyewa = etNamaPenyewa.getText().toString().trim();
        String lamaSewaStr = etLamaSewa.getText().toString().trim();
        String uangBayarStr = etUangBayar.getText().toString().trim();

        // Validasi dasar
        if (namaPenyewa.isEmpty()) {
            etNamaPenyewa.setError("Masukkan nama penyewa");
            etNamaPenyewa.requestFocus();
            return;
        }

        if (lamaSewaStr.isEmpty()) {
            etLamaSewa.setError("Masukkan lama sewa");
            etLamaSewa.requestFocus();
            return;
        }

        if (uangBayarStr.isEmpty()) {
            etUangBayar.setError("Masukkan uang bayar");
            etUangBayar.requestFocus();
            return;
        }

        // Validasi khusus untuk transfer bank
        if (!selectedMetodePembayaran.equals("COD") && buktiTransferPath == null) {
            Toast.makeText(this, "Harap unggah bukti transfer terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int lamaSewa = Integer.parseInt(lamaSewaStr);
            int uangBayar = Integer.parseInt(uangBayarStr);

            if (lamaSewa <= 0) {
                etLamaSewa.setError("Lama sewa harus lebih dari 0");
                etLamaSewa.requestFocus();
                return;
            }

            if (uangBayar <= 0) {
                etUangBayar.setError("Uang bayar harus lebih dari 0");
                etUangBayar.requestFocus();
                return;
            }

            // Hitung total jika belum
            if (totalHarga == 0) {
                hitungTotal();
            }

            // Hitung kembalian
            int uangKembali = uangBayar - totalHarga;

            if (uangKembali < 0) {
                Toast.makeText(this, "Uang bayar kurang!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Simpan ke database
            Sewa sewa = new Sewa(namaPenyewa, selectedMobil.getNama(), lamaSewa,
                    totalHarga, uangBayar, uangKembali);
            sewa.setMetodePembayaran(selectedMetodePembayaran);
            sewa.setBuktiTransferPath(buktiTransferPath); // Simpan path bukti transfer
            long id = db.addSewa(sewa);

            if (id != -1) {
                // Pindah ke halaman pembayaran
                Intent intent = new Intent(SewaActivity.this, PembayaranActivity.class);
                intent.putExtra("nama", namaPenyewa);
                intent.putExtra("mobil", selectedMobil.getNama());
                intent.putExtra("lama_sewa", lamaSewa);
                intent.putExtra("total", totalHarga);
                intent.putExtra("uang_bayar", uangBayar);
                intent.putExtra("uang_kembali", uangKembali);
                intent.putExtra("metode_bayar", selectedMetodePembayaran);
                intent.putExtra("bukti_transfer", buktiTransferPath); // Kirim path bukti
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Gagal menyimpan data sewa!", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Masukkan angka yang valid", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper method untuk format currency
    private String formatCurrency(int amount) {
        return String.format("%,d", amount).replace(",", ".");
    }

    @Override
    protected void onDestroy() {
        if (db != null) {
            db.close();
        }
        super.onDestroy();
    }
}