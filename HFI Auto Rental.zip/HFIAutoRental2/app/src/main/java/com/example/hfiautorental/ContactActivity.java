package com.example.hfiautorental;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        ImageView ivFacebook = findViewById(R.id.iv_facebook);
        ImageView ivWhatsapp = findViewById(R.id.iv_whatsapp);
        ImageView ivInstagram = findViewById(R.id.iv_instagram);
        ImageView ivYoutube = findViewById(R.id.iv_youtube);
        ImageView ivRekening = findViewById(R.id.iv_rekening);

        TextView tvFacebook = findViewById(R.id.tv_facebook);
        TextView tvWhatsapp = findViewById(R.id.tv_whatsapp);
        TextView tvInstagram = findViewById(R.id.tv_instagram);
        TextView tvYoutube = findViewById(R.id.tv_youtube);
        TextView tvRekening = findViewById(R.id.tv_rekening);
        TextView tvAtasNama = findViewById(R.id.tv_atas_nama);

        View btnBackHome = findViewById(R.id.btn_back_home);
        View btnRekening = findViewById(R.id.btn_rekening);
        View btnCopyRekening = findViewById(R.id.btn_copy_rekening);

        // Set click listeners untuk social media
        setClick(ivFacebook, "https://facebook.com/AgusNovianto");
        setClick(tvFacebook, "https://facebook.com/AgusNovianto");

        setClick(ivWhatsapp, "https://wa.me/6285156586447");
        setClick(tvWhatsapp, "https://wa.me/6285156586447");

        setClick(ivInstagram, "https://instagram.com/guz_00");
        setClick(tvInstagram, "https://instagram.com/guz_00");

        setClick(ivYoutube, "https://youtube.com/c/AgusNovianto");
        setClick(tvYoutube, "https://youtube.com/c/AgusNovianto");

        // Click listener untuk nomor rekening (opsional: bisa untuk copy juga)
        btnRekening.setOnClickListener(v -> {
            String rekeningText = "Bank BCA\nNomor: 1234567890\nAtas Nama: HFI AutoRental";
            copyToClipboard("1234567890", "Nomor rekening telah disalin");
        });

        // Tombol salin rekening
        btnCopyRekening.setOnClickListener(v -> {
            String nomorRekening = "1234567890";
            copyToClipboard(nomorRekening, "Nomor rekening BCA " + nomorRekening + " telah disalin");
        });

        btnBackHome.setOnClickListener(v -> {
            startActivity(new Intent(ContactActivity.this, DashboardActivity.class));
            finish();
        });
    }

    private void setClick(View v, String url) {
        v.setOnClickListener(view -> openUrl(url));
    }

    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

    private void copyToClipboard(String text, String toastMessage) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("rekening", text);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();
    }
}